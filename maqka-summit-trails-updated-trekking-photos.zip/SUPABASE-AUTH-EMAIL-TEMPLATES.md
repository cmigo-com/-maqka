# MAQKA SUMMIT TRAILS AND SAFARIS — Supabase Auth Email Templates

The application uses Supabase Auth for account verification, login and password recovery. These templates should be pasted into the Supabase Dashboard under Authentication → Email Templates.

## Password recovery subject
Reset your MAQKA SUMMIT TRAILS AND SAFARIS password

## Password recovery body
Use the Supabase-provided confirmation URL variable for the button/link. Keep the HTML branded with MAQKA SUMMIT TRAILS AND SAFARIS forest green, cream and gold. Do not put passwords, API keys or database credentials in the message.

Recommended body copy:

> SUMMIT TRAILS
> HIKING • TREKKING • MOUNTAIN ADVENTURES
>
> Hello,
>
> We received a request to reset your MAQKA SUMMIT TRAILS AND SAFARIS account password. Use the secure button below to choose a new password.
>
> Reset My Password
>
> If you did not request this, you can safely ignore this email.
>
> MAQKA SUMMIT TRAILS AND SAFARIS · Nanyuki, Kenya · 0713177186 · waltermichael357@gmail.com

Use Supabase's current password-reset URL variable in the button href; do not hard-code a token or password into the template.
