# MAQKA SUMMIT TRAILS AND SAFARIS — Production Upgrade (Original Website Preserved)

This project keeps the supplied MAQKA SUMMIT TRAILS AND SAFARIS website as the visual/UI base. The existing pages, wording, layout, colours, navigation, adventure cards, gear checklist, booking interface, customer dashboard, admin dashboard and modals are retained. The main change is that the former browser-only mock functions are replaced with a real backend bridge.

## What is now connected
- Supabase Auth for customer/admin login and registration.
- PostgreSQL/Supabase tables for adventures, departure dates, bookings, travelers, payments and contact messages.
- Server-side admin authorization.
- Server-side M-PESA Daraja STK Push endpoint and callback handler.
- Booking slot validation and slot deduction.
- Customer booking retrieval.
- Trekker profile storage.
- Admin adventure/date creation and payment logging.
- CSV audit export remains available in the same UI.
- Optional Resend email notifications for booking/contact events.

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `database/schema.sql`.
3. Create the first user through the website registration form.
4. Find that user's UUID in Supabase Auth and run:
   `update public.profiles set role='admin' where id='YOUR-AUTH-USER-UUID';`
5. Copy `.env.example` to `.env` locally or add the same variables in Vercel Project Settings → Environment Variables.
6. Add your Safaricom Daraja credentials. For production, the callback URL must be your deployed HTTPS URL ending in `/api/mpesa/callback`.
7. Optional: add Resend variables if you want email notifications.
8. Deploy the project root to Vercel. There is no frontend subdirectory in this version, so the Vercel Root Directory should be the project root.

## Important security points
- The old hard-coded admin login values were removed from the login form.
- Supabase service-role and Safaricom secrets are only read by server-side Vercel functions.
- Never put `SUPABASE_SERVICE_ROLE_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_PASSKEY` or `RESEND_API_KEY` in browser JavaScript.
- Use Daraja sandbox first, then switch `MPESA_ENV=production` after your Safaricom production credentials/callback are ready.

## Files
- `index.html` — the original supplied MAQKA SUMMIT TRAILS AND SAFARIS UI, with only the inline mock script replaced by the functionality bridge.
- `app.js` — browser-side functionality and API calls.
- `api/` — Vercel serverless API endpoints.
- `database/schema.sql` — Supabase database schema and original adventure/date seed data.
- `.env.example` — required environment variables.
- `vercel.json` — Vercel serverless-function runtime configuration.

## Destination research and catalogue

The existing MAQKA SUMMIT TRAILS AND SAFARIS UI remains the base. Destination research is stored in `database/destination_catalogue.json` and the non-public research-ready records can be loaded with `database/seed_destination_catalogue.sql`. Unverified records are inactive by default. See `RESEARCH-AND-CATALOGUE.md` for the verification workflow.

Do not upload Tripadvisor photos or copy Tripadvisor reviews/descriptions. Use MAQKA SUMMIT TRAILS AND SAFARIS-owned or properly licensed destination photography.

## Phase 1 update — 2026-09-29
- Replaced the four adventure image assets with the four photos supplied in the current conversation.
- Added optimized WebP copies and an adventure image manifest at `assets/adventures/manifest.json`.
- Removed the external Unsplash hero image; the home hero now uses a supplied MAQKA SUMMIT TRAILS AND SAFARIS image.
- Added the supplied images to the home gallery, About section, Why Choose section, and adventure-detail gallery fallback.
- Added admin image URL/gallery fields so image assignments can be changed without redesigning the UI.
- Added `PRICE-RESEARCH-HIKEMANIAK.md` with market-reference prices. These values are not automatically used as MAQKA SUMMIT TRAILS AND SAFARIS prices.
- Kept research-only destinations inactive until MAQKA SUMMIT TRAILS AND SAFARIS pricing and commercial details are configured.

## New platform capabilities

This continuation keeps the existing MAQKA SUMMIT TRAILS AND SAFARIS Customer Dashboard and Admin Dashboard and adds:

- Public contact messaging without login, conversation IDs and secure reply tokens.
- Admin inquiry inbox with search, status management, conversation history and replies.
- Branded transactional email templates for booking received/confirmed, verified payments, status changes, reminders and customer inquiries.
- Dedicated `/adventures`, `/destinations`, `/safari-packages`, `/gallery`, `/achievements` and `/faq` routes using the existing single-page UI.
- Admin content management for destinations, safari packages, safari departure dates, gallery records, verified achievements and FAQs.
- Adult/child participant counts with server-side total calculation and booking price snapshots.
- Atomic departure-slot reservation to prevent concurrent overbooking.
- Customer booking notifications and participant/member records.
- Booking search by reference, customer, phone, adventure and travel date plus payment-state filtering.

## Database upgrade order

Run `database/schema.sql` first, then `database/seed_content.sql` in Supabase SQL Editor. The schema is additive and preserves existing tables and bookings.

## Email configuration

Set `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `ADMIN_NOTIFICATION_EMAIL` and `SITE_URL`. The application never reports an email as sent when the provider is unavailable. See `SUPABASE-AUTH-EMAIL-TEMPLATES.md` for branded password-reset template guidance.

## Payments

Daraja credentials remain server-side only. M-PESA payments are recorded as pending until the Safaricom callback verifies them. No M-PESA PIN is collected or stored.

## Images

Only the MAQKA SUMMIT TRAILS AND SAFARIS uploaded photographs included in `assets/adventures/source` and their optimized versions are used by the current gallery/content seed. AI-generated copies and external stock/Unsplash references are not used.

## Mount Kenya Hiking catalogue
The Adventures page now groups four separate Mount Kenya routes under **Mount Kenya Hiking**:
- Sirimon Route — 49.7 km, 2,706 m elevation gain, 18 h 23 min
- Naro Moru Route — 47.3 km, 2,706 m elevation gain
- Chogoria Route — 41.4 km, 2,461 m elevation gain, 15 h 18 min
- Mackinder Hike — 47.6 km, 2,798 m elevation gain, 15–18 hr

Each route has its own AI-generated project image and its own adventure record so additional routes, prices, dates and photos can be added later from the Admin Dashboard. The supplied route details are kept separate rather than merged into one Mount Kenya listing.

Database setup: run `database/migration_mount_kenya_routes.sql` after the base schema, or use the updated `database/seed_content.sql` included in this build.

### Other Kenya Hiking Trails catalogue
The Adventures catalogue now supports a separate **Other Kenya Hiking Trails** section. Run `database/migration_other_kenya_hiking.sql` in Supabase SQL Editor after the existing schema/migrations to add the 14 separate trail records. Prices and departures are intentionally left for MAQKA to confirm in the Admin Dashboard.
