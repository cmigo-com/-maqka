-- Summit Trails content seed: destinations are inactive until Summit Trails verifies commercial details.

insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Karura Forest','karura-forest','Northern Nairobi','A green urban escape with shaded trails, streams, waterfalls and forest scenery within Nairobi.','["Forest walks", "Waterfalls", "Mau Mau caves", "Bird and butterfly watching"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Ngong Hills','ngong-hills','Ngong Hills / Kajiado','A ridge-walking adventure across open highland slopes with broad views over the Nairobi region and Rift Valley.','["Rolling ridges", "Panoramic viewpoints", "Open highland scenery"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Mount Kenya','mount-kenya','Mount Kenya National Park','Kenya''s premier high-altitude trekking destination, with forest, moorland and alpine terrain leading toward the mountain''s major summits.','["Point Lenana", "Alpine landscapes", "High-altitude trekking", "Forest and moorland zones"]'::jsonb,'',true,true) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Mount Satima','mount-satima','Aberdare National Park / Aberdare Range','A high-altitude Aberdare adventure across exposed moorland and rugged mountain terrain.','["Afro-alpine moorland", "High-elevation views", "Aberdare ridge scenery"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Torok Waterfalls','torok-waterfalls','Near Iten / C51 corridor','A waterfall-focused hike in the Elgeyo-Marakwet highlands, combining rugged walking with views toward a major cascade.','["Waterfall scenery", "Highland views", "Nature photography"]'::jsonb,'/assets/adventures/optimized/torok-waterfalls.webp',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Ragia Falls','ragia-falls','Ragia Forest, Aberdare Forest Reserve','A forest-and-waterfall trek through bamboo and river terrain toward Ragia Falls in the Aberdare ecosystem.','["Bamboo forest", "River sections", "Waterfalls", "Forest trail experience"]'::jsonb,'/assets/adventures/optimized/ragia-falls.webp',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Seven Ponds / Table Mountain','seven-ponds-table-mountain','Northern Aberdare moorlands','A high-altitude Aberdare traverse through open moorland to distinctive summit and tarn landscapes.','["Seven alpine ponds", "Table Mountain summit", "Moorland views", "Aberdare highlands"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Njine Kabia Falls','njine-kabia-falls','Near Kerugoya / Kirinyaga Central','A local waterfall outing combining a short nature hike with a scenic cascade and rural highland surroundings.','["Waterfall", "Nature photography", "Local outdoor experience"]'::jsonb,'/assets/adventures/optimized/njine-kabia-falls.webp',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Chagaik Arboretum','chagaik-arboretum','Near Brooke, Kericho','A quiet highland tree and tea-country setting suited to relaxed walking, photography and nature observation.','["Indigenous and exotic trees", "Tea-country scenery", "Nature walk"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Aberdare Hiking Adventure / Aberdare Forest','aberdare-hiking-adventure-aberdare-forest','Aberdare Range','A flexible mountain-and-forest category covering selected Aberdare trails, from forest walks to high moorland routes.','["Bamboo and forest zones", "Waterfalls", "High moorlands", "Mountain viewpoints"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Hell''s Gate National Park','hell-s-gate-national-park','Naivasha / Great Rift Valley','A Rift Valley adventure combining open landscapes, cliffs, gorges and geothermal scenery with active outdoor routes.','["Gorges", "Cliffs", "Geothermal landscape", "Hiking and cycling"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Ndere Island National Park','ndere-island-national-park','Lake Victoria / Winam Gulf','A lakeside island adventure combining walking trails, open grassland, panoramic water views and wildlife observation.','["Island trails", "Lake Victoria views", "Birdlife", "Wildlife viewing"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Maragoli Hills','maragoli-hills','Maragoli Hills','A western Kenya hill and forest destination identified for scenic hiking and nature exploration.','["Highland scenery", "Forest setting", "Western Kenya views"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Menengai Crater','menengai-crater','Nakuru','A Rift Valley crater landscape suited to scenic walking, viewpoints and volcanic-landform exploration.','["Crater rim views", "Rift Valley scenery", "Volcanic landscape"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Mount Longonot','mount-longonot','Mount Longonot National Park','A volcanic mountain hike through rugged ridges and valleys, culminating in wide views around the crater rim.','["Crater rim", "Rugged ridges", "Rift Valley views", "Forest inside crater"]'::jsonb,'',true,true) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Mount Lesatima & Dragon Teeth','mount-lesatima-dragon-teeth','Aberdare Range','A rugged Aberdare highland adventure combining high-elevation terrain with distinctive rock formations.','["High-altitude moorland", "Dragon Teeth formations", "Mountain views"]'::jsonb,'/assets/adventures/optimized/mount-lesatima-dragon-teeth.webp',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Mount Elgon','mount-elgon','Mount Elgon National Park','A large volcanic mountain landscape rising through forest, bamboo, heath and alpine zones into a distinctive high-altitude wilderness.','["Montane forest", "Bamboo and Podocarpus zones", "Alpine moorland", "High-altitude scenery"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Kakamega Forest','kakamega-forest','Kakamega Forest National Reserve','A rainforest walking experience through one of Kenya''s most important remaining tropical forest landscapes, rich in birds, plants and primates.','["Rainforest canopy", "Birdlife", "Butterflies", "Primates", "Waterfalls and viewpoints"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();
insert into public.destinations (name,slug,location,description,highlights,image_url,active,featured) values ('Lake Elementaita','lake-elementaita','Great Rift Valley','A scenic Rift Valley outing combining lakeside landscapes, birdlife and nature walking around a protected wetland environment.','["Lake views", "Flamingos and waterbirds", "Scenic trails", "Hot springs"]'::jsonb,'',false,false) on conflict (slug) do update set description=excluded.description, highlights=excluded.highlights, image_url=coalesce(excluded.image_url,public.destinations.image_url), updated_at=now();

-- Initial FAQ content. These answers are Summit Trails wording, not copied source material.
insert into public.faqs (question,answer,active,sort_order) values ('How do I book a hiking adventure?','Choose an adventure, select an available departure and number of adults/children, review the server-calculated total, then submit your booking. Summit Trails will review the request and confirm it according to the configured booking process.',true,1) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Can I book for a group?','Yes. Select the total number of adults and children for your group. Availability is checked against the selected departure before the booking is accepted.',true,2) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('How many people can I book for?','You can book up to the number of spaces available for the selected departure. The system will stop a booking if it exceeds the remaining capacity.',true,3) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Can children participate in selected adventures?','Some adventures can support children. Child booking is enabled only when Summit Trails has configured a child price for that adventure.',true,4) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('What should I bring for a hike?','Use the adventure-specific preparation and gear information on the adventure page. Requirements vary by route, duration, elevation and weather.',true,5) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('What happens after I make a booking?','Your request is stored with the selected departure, member counts and price snapshot. It remains pending until Summit Trails completes its confirmation process.',true,6) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Can I pay in installments?','Yes, where Summit Trails has enabled installment payments. Your dashboard shows the total, verified payments and remaining balance.',true,7) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('How do I know my booking is confirmed?','Your Customer Dashboard will show the booking status, and Summit Trails can also send a confirmation email when the booking is approved.',true,8) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Can I change my booking?','Contact Summit Trails as soon as possible. Changes depend on departure availability and the booking terms for the adventure.',true,9) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('What happens if an adventure is cancelled?','Summit Trails will communicate the status and any applicable next steps directly with affected customers.',true,10) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('How do I contact Summit Trails?','Call 0713177186, email waltermichael357@gmail.com, or use WhatsApp. Summit Trails is based in Nanyuki, Kenya.',true,11) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Do you offer private/group trips?','Private or group arrangements can be discussed with Summit Trails. Contact the team with your preferred destination, dates and group size.',true,12) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Do you offer safari packages?','Summit Trails can publish safari packages when their official itinerary, pricing and availability have been configured by the administrator.',true,13) on conflict do nothing;
insert into public.faqs (question,answer,active,sort_order) values ('Where is Summit Trails located?','Summit Trails is based in Nanyuki, Kenya.',true,14) on conflict do nothing;

-- Uploaded Summit Trails photographs currently available in the project. No stock or generated image is seeded.
insert into public.gallery_images (title,caption,category,image_url,featured,active,sort_order) values ('Mount Lesatima & Dragon Teeth','Summit Trails mountain adventure photograph.','Mountains','/assets/adventures/optimized/mount-lesatima-dragon-teeth.webp',true,true,1),('Njine Kabia Falls','Summit Trails waterfall adventure photograph.','Waterfalls','/assets/adventures/optimized/njine-kabia-falls.webp',true,true,2),('Ragia Falls','Summit Trails waterfall adventure photograph.','Waterfalls','/assets/adventures/optimized/ragia-falls.webp',false,true,3),('Torok Waterfalls','Summit Trails waterfall adventure photograph.','Waterfalls','/assets/adventures/optimized/torok-waterfalls.webp',false,true,4) on conflict (image_url) do update set caption=excluded.caption, category=excluded.category, active=true;-- MAQKA SUMMIT TRAILS AND SAFARIS
-- Mount Kenya route catalogue: separate adventure records under one category.
-- Prices are intentionally 0 until MAQKA confirms them in the admin catalogue.

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Sirimon Route — Mount Kenya','mount-kenya-sirimon-route','Mount Kenya Hiking','Laikipia / Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,706 m elevation gain','Sirimon Route — Out & Back','49.7 km',1,'18 h 23 min','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Try this 49.7-km out-and-back trail near Nanyuki, Central. Generally considered a challenging route, it takes an average of 18 h 23 min to complete. This is a very popular area for backpacking, camping, and hiking, so you will likely encounter other people while exploring. The trail is open year-round and is beautiful to visit anytime.',
'The Sirimon route offers a demanding Mount Kenya hiking experience with highland scenery, alpine terrain and long-distance trekking.',
'["Narumoro / Naro Moru area","Mount Kenya National Park","Backpacking, camping and hiking","Open year-round"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'Year-round; conditions vary by season',
'["Sturdy hiking boots","Warm layered clothing","Rain protection","Headlamp","Water and high-energy snacks"]'::jsonb,
'Challenging high-altitude terrain requires suitable preparation, pacing, weather awareness and appropriate guiding. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/sirimon-route-ai.webp"]'::jsonb,true,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Naro Moru Route — Mount Kenya','mount-kenya-naro-moru-route','Mount Kenya Hiking','Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,706 m elevation gain','Naro Moru Route — Out & Back','47.3 km',1,'Challenging trail','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Enjoy this 47.3-km out-and-back trail near Nanyuki, Central. Generally considered a challenging route. This is a popular trail for backpacking, camping, and hiking, but you can still enjoy some solitude during quieter times of day. The best times to visit the trail are August through October.',
'The Naro Moru route is presented as a separate Mount Kenya hiking option, with its own route profile, photo and details so customers can explore it independently.',
'["Mount Kenya National Park","Popular backpacking and hiking route","Quieter periods may offer more solitude","August–October listed as a preferred period in the supplied trail information"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'August–October, based on the supplied trail information',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/naro-moru-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Chogoria Route — Mount Kenya','mount-kenya-chogoria-route','Mount Kenya Hiking','Meru','Mount Kenya','Near Timau, Meru','High-altitude mountain trail','2,461 m elevation gain','Chogoria Route — Point to Point','41.4 km',1,'15 h 18 min','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Discover this 41.4-km point-to-point trail near Timau, Meru. Generally considered a challenging route, it takes an average of 15 h 18 min to complete. This trail is great for backpacking, camping, and hiking, and it is unlikely you will encounter many other people while exploring.',
'The Chogoria route is a separate Mount Kenya adventure featuring scenic highland landscapes and a point-to-point trekking experience.',
'["41.4 km point-to-point trail","Backpacking and camping","Scenic alpine landscapes","Potential for quieter trail conditions"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'To be confirmed',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/chogoria-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Mackinder Hike — Mount Kenya','mount-kenya-mackinder-hike','Mount Kenya Hiking','Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,798 m elevation gain','Mackinder Hike — Point to Point','47.6 km',1,'15–18 hr','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Try this 47.6-km point-to-point trail near Nanyuki, Central. Generally considered a challenging route. This is a popular trail for camping and hiking, but you can still enjoy some solitude during quieter times of day.',
'The Mackinder Hike is listed as its own Mount Kenya route so customers can view its distance, elevation gain and route type separately from the other Mount Kenya adventures.',
'["47.6 km point-to-point trail","Camping and hiking","High-altitude mountain scenery","Potential for quieter conditions"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'To be confirmed',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/mackinder-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();
