-- MAQKA SUMMIT TRAILS AND SAFARIS
-- Mount Kenya route catalogue: separate adventure records under one category.
-- Prices are intentionally 0 until MAQKA confirms them in the admin catalogue.

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Sirimon Route — Mount Kenya','mount-kenya-sirimon-route','Mount Kenya Hiking','Laikipia / Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,706 m elevation gain','Sirimon Route — Out & Back','49.7 km',1,'18 h 23 min','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Try this 49.7-km out-and-back trail near Nanyuki, Central. Generally considered a challenging route, it takes an average of 18 h 23 min to complete. This is a very popular area for backpacking, camping, and hiking, so you will likely encounter other people while exploring. The trail is open year-round and is beautiful to visit anytime.',
'The Sirimon route offers a demanding Mount Kenya hiking experience with highland scenery, alpine terrain and long-distance trekking.',
'["Narumoro / Naro Moru area","Mount Kenya National Park","Backpacking, camping and hiking","Open year-round"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'Year-round; conditions vary by season',
'["Sturdy hiking boots","Warm layered clothing","Rain protection","Headlamp","Water and high-energy snacks"]'::jsonb,
'Challenging high-altitude terrain requires suitable preparation, pacing, weather awareness and appropriate guiding. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/sirimon-route-ai.webp"]'::jsonb,true,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Naro Moru Route — Mount Kenya','mount-kenya-naro-moru-route','Mount Kenya Hiking','Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,706 m elevation gain','Naro Moru Route — Out & Back','47.3 km',1,'Challenging trail','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Enjoy this 47.3-km out-and-back trail near Nanyuki, Central. Generally considered a challenging route. This is a popular trail for backpacking, camping, and hiking, but you can still enjoy some solitude during quieter times of day. The best times to visit the trail are August through October.',
'The Naro Moru route is presented as a separate Mount Kenya hiking option, with its own route profile, photo and details so customers can explore it independently.',
'["Mount Kenya National Park","Popular backpacking and hiking route","Quieter periods may offer more solitude","August–October listed as a preferred period in the supplied trail information"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'August–October, based on the supplied trail information',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/naro-moru-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Chogoria Route — Mount Kenya','mount-kenya-chogoria-route','Mount Kenya Hiking','Meru','Mount Kenya','Near Timau, Meru','High-altitude mountain trail','2,461 m elevation gain','Chogoria Route — Point to Point','41.4 km',1,'15 h 18 min','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Discover this 41.4-km point-to-point trail near Timau, Meru. Generally considered a challenging route, it takes an average of 15 h 18 min to complete. This trail is great for backpacking, camping, and hiking, and it is unlikely you will encounter many other people while exploring.',
'The Chogoria route is a separate Mount Kenya adventure featuring scenic highland landscapes and a point-to-point trekking experience.',
'["41.4 km point-to-point trail","Backpacking and camping","Scenic alpine landscapes","Potential for quieter trail conditions"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'To be confirmed',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/chogoria-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();

insert into public.adventures (
  title, slug, category, county, mountain_name, location, terrain_type, elevation,
  route, approximate_distance, duration_days, duration_label, difficulty,
  price_per_person, adult_price, child_price, currency, price_status,
  description, detailed_description, highlights, suitable_for, trip_formats,
  best_season, what_to_bring, safety_information, itinerary, inclusions, exclusions,
  gallery_images, featured, active, verification_status, source_notes
) values
('Mackinder Hike — Mount Kenya','mount-kenya-mackinder-hike','Mount Kenya Hiking','Central Kenya','Mount Kenya','Near Nanyuki, Central Kenya','High-altitude mountain trail','2,798 m elevation gain','Mackinder Hike — Point to Point','47.6 km',1,'15–18 hr','Challenging',0,0,null,'KES','Pricing to be confirmed',
'Try this 47.6-km point-to-point trail near Nanyuki, Central. Generally considered a challenging route. This is a popular trail for camping and hiking, but you can still enjoy some solitude during quieter times of day.',
'The Mackinder Hike is listed as its own Mount Kenya route so customers can view its distance, elevation gain and route type separately from the other Mount Kenya adventures.',
'["47.6 km point-to-point trail","Camping and hiking","High-altitude mountain scenery","Potential for quieter conditions"]'::jsonb,
'["Experienced hikers","Backpackers","Camping groups"]'::jsonb,
'["Hiking","Backpacking","Camping"]'::jsonb,
'To be confirmed',
'["Hiking boots","Warm layers","Rain protection","Headlamp","Water and snacks"]'::jsonb,
'Challenging mountain terrain requires appropriate preparation, weather awareness and route-specific guidance. Check current park guidance before departure.',
'Route timing and overnight plan to be confirmed with MAQKA based on the selected itinerary.','To be confirmed','To be confirmed',
'["/assets/adventures/optimized/mount-kenya/mackinder-route-ai.webp"]'::jsonb,false,true,'Supplied trail information; route pricing and operational details pending MAQKA confirmation.',
'["User-supplied trail information","AI-generated route image"]'::jsonb)
on conflict (slug) do update set
  title=excluded.title, category=excluded.category, county=excluded.county, mountain_name=excluded.mountain_name,
  location=excluded.location, terrain_type=excluded.terrain_type, elevation=excluded.elevation, route=excluded.route,
  approximate_distance=excluded.approximate_distance, duration_label=excluded.duration_label, difficulty=excluded.difficulty,
  description=excluded.description, detailed_description=excluded.detailed_description, highlights=excluded.highlights,
  suitable_for=excluded.suitable_for, trip_formats=excluded.trip_formats, best_season=excluded.best_season,
  what_to_bring=excluded.what_to_bring, safety_information=excluded.safety_information, itinerary=excluded.itinerary,
  inclusions=excluded.inclusions, exclusions=excluded.exclusions, gallery_images=excluded.gallery_images,
  featured=excluded.featured, active=excluded.active, price_status=excluded.price_status, updated_at=now();
