const { adminClient, send } = require('../_lib/supabase');

module.exports = async (req,res) => {
  try {
    if (req.method !== 'GET') return send(res,405,{error:'Method not allowed'});
    const db=adminClient();
    let q=db.from('adventures').select('*, departures(*)').order('featured',{ascending:false}).order('id');
    const p=req.query||{};
    if(p.active !== 'all') q=q.eq('active',true);
    if(p.category) q=q.ilike('category',`%${p.category}%`);
    if(p.county) q=q.ilike('county',`%${p.county}%`);
    if(p.difficulty) q=q.eq('difficulty',p.difficulty);
    if(p.featured==='true') q=q.eq('featured',true);
    if(p.search){
      const s=String(p.search).replace(/[%_,]/g,' ');
      q=q.or(`title.ilike.%${s}%,mountain_name.ilike.%${s}%,route.ilike.%${s}%,county.ilike.%${s}%,location.ilike.%${s}%,category.ilike.%${s}%`);
    }
    if(p.min_price) q=q.gte('adult_price',Number(p.min_price));
    if(p.max_price) q=q.lte('adult_price',Number(p.max_price));
    const {data,error}=await q;
    if(error) throw error;
    let adventures=data||[];
    if(p.departure_date){adventures=adventures.filter(a=>(a.departures||[]).some(d=>d.start_date<=p.departure_date && d.end_date>=p.departure_date));}
    send(res,200,{adventures});
  } catch(e) { send(res,e.statusCode||500,{error:e.message}); }
};
