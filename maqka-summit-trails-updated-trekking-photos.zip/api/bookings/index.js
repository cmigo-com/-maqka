const { requireUser, send } = require('../_lib/supabase');
const { sendEmail, templates } = require('../_lib/email');

const clean = (v,max=500) => String(v ?? '').trim().slice(0,max);

module.exports = async (req,res) => {
  try {
    const {user,db}=await requireUser(req);
    if(req.method==='GET') {
      const [{data,error},{data:notifications,error:nErr}]=await Promise.all([
        db.from('bookings').select('*, adventures(*), departures(*), travelers(*), booking_members(*), payments(*)').eq('user_id',user.id).order('created_at',{ascending:false}),
        db.from('notifications').select('*').eq('user_id',user.id).order('created_at',{ascending:false}).limit(30)
      ]);
      if(error) throw error; if(nErr) throw nErr;
      return send(res,200,{bookings:data||[],notifications:notifications||[]});
    }
    if(req.method!=='POST') return send(res,405,{error:'Method not allowed'});
    if(req.body?.action==='mark_notifications_read'){
      const ids=Array.isArray(req.body.notification_ids)?req.body.notification_ids.map(Number).filter(Boolean):[];
      if(ids.length){const {error}=await db.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',user.id).in('id',ids);if(error)throw error;}
      return send(res,200,{ok:true});
    }
    if(req.body?.action==='update_profile'){
      const full_name=clean(req.body.full_name,120), phone_number=clean(req.body.phone_number,40);
      if(!full_name)return send(res,400,{error:'Full name is required.'});
      const {data:profile,error}=await db.from('profiles').update({full_name,phone_number,updated_at:new Date().toISOString()}).eq('id',user.id).select('*').single();
      if(error)throw error;
      return send(res,200,{profile});
    }
    if(req.body?.action==='cancel'){
      const bookingId=Number(req.body.booking_id);
      if(!bookingId)return send(res,400,{error:'Booking ID is required.'});
      const {data:booking,error}=await db.rpc('cancel_customer_booking',{p_booking_id:bookingId,p_user_id:user.id});
      if(error) return send(res,409,{error:error.message});
      await db.from('notifications').insert({user_id:user.id,booking_id:booking.id,type:'booking_status',title:'Booking cancelled',message:`Your MAQKA SUMMIT TRAILS AND SAFARIS booking ${booking.booking_reference} has been cancelled. If you already paid, please contact MAQKA SUMMIT TRAILS AND SAFARIS about any applicable refund arrangements.`});
      const {data:auth}=await db.auth.admin.getUserById(user.id);
      await sendEmail({to:auth?.user?.email||user.email,subject:'MAQKA SUMMIT TRAILS AND SAFARIS Booking Cancelled',html:templates.statusUpdate({name:user.user_metadata?.full_name||'MAQKA SUMMIT TRAILS AND SAFARIS customer',booking,status:'cancelled',note:'If you have already made a payment, please contact MAQKA SUMMIT TRAILS AND SAFARIS to discuss any applicable refund arrangements.'})}).catch(()=>{});
      return send(res,200,{booking});
    }
    const {adventure_id,departure_id}=req.body||{};
    const adults=Number(req.body?.adults||0), children=Number(req.body?.children||0);
    const trekkers=adults+children;
    const members=Array.isArray(req.body?.members)?req.body.members:[];
    if(!adventure_id||!departure_id||!Number.isInteger(adults)||!Number.isInteger(children)||adults<1||children<0) return send(res,400,{error:'At least one adult is required.'});
    if(members.length>trekkers) return send(res,400,{error:'Participant details exceed the selected number of members.'});
    const {data:adv,error:aErr}=await db.from('adventures').select('*').eq('id',adventure_id).single(); if(aErr) throw aErr;
    if(!adv.active) return send(res,409,{error:'This adventure is not currently available for booking.'});
    const {data:dep,error:dErr}=await db.from('departures').select('*').eq('id',departure_id).single(); if(dErr) throw dErr;
    if(Number(dep.adventure_id)!==Number(adventure_id)) return send(res,400,{error:'Selected departure does not belong to this adventure.'});
    if(children>0 && (adv.child_price===null || adv.child_price===undefined)) return send(res,409,{error:'Child pricing has not been configured for this adventure yet.'});
    const adultUnit=Number(adv.adult_price ?? adv.price_per_person ?? 0);
    const childUnit=children>0?Number(adv.child_price):0;
    const discount=Math.max(0,Number(adv.discount||0));
    const total=Math.max(0,(adultUnit*adults)+(childUnit*children)-discount);
    const {data:reserved,error:rErr}=await db.rpc('reserve_departure_slots',{p_departure_id:Number(departure_id),p_members:trekkers});
    if(rErr) return send(res,409,{error:rErr.message.includes('Only')?rErr.message:rErr.message});
    const ref='ST-'+Date.now().toString().slice(-6)+'-'+Math.floor(10+Math.random()*90);
    const {data:booking,error:bErr}=await db.from('bookings').insert({booking_reference:ref,user_id:user.id,adventure_id,departure_id,adults,children,number_of_trekkers:trekkers,adult_unit_price:adultUnit,child_unit_price:children?childUnit:null,discount,total_price:total,status:'pending',admin_note:'Awaiting MAQKA SUMMIT TRAILS AND SAFARIS confirmation and payment verification'}).select().single();
    if(bErr){await db.from('departures').update({available_slots:Number(reserved.available_slots)+trekkers}).eq('id',departure_id);throw bErr;}
    if(members.length){
      const rows=members.slice(0,trekkers).map(m=>({booking_id:booking.id,full_name:clean(m.full_name,120),member_type:m.member_type==='child'?'child':'adult',age:m.age?Number(m.age):null,emergency_contact_name:clean(m.emergency_contact_name,120)||null,emergency_contact_phone:clean(m.emergency_contact_phone,40)||null})).filter(m=>m.full_name);
      if(rows.length){const {error:mErr}=await db.from('booking_members').insert(rows);if(mErr){await db.from('bookings').delete().eq('id',booking.id);await db.from('departures').update({available_slots:Number(reserved.available_slots)+trekkers}).eq('id',departure_id);throw mErr;}}
    }
    const bookingForEmail={...booking,amount_paid:0};
    await sendEmail({to:user.email,subject:'Booking Received — MAQKA SUMMIT TRAILS AND SAFARIS',html:templates.bookingReceived({name:user.user_metadata?.full_name||'MAQKA SUMMIT TRAILS AND SAFARIS guest',booking:bookingForEmail,adventure:adv,departure:dep})}).catch(()=>{});
    if(process.env.ADMIN_NOTIFICATION_EMAIL) await sendEmail({to:process.env.ADMIN_NOTIFICATION_EMAIL,subject:`New MAQKA SUMMIT TRAILS AND SAFARIS booking ${ref}`,html:templates.bookingReceived({name:user.user_metadata?.full_name||user.email,booking:bookingForEmail,adventure:adv,departure:dep})}).catch(()=>{});
    return send(res,201,{booking,available_slots_after:reserved.available_slots});
  } catch(e) { send(res,e.statusCode||500,{error:e.message}); }
};
