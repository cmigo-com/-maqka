const { createClient } = require('@supabase/supabase-js');

function adminClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}

function publicClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}

async function requireUser(req) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) throw Object.assign(new Error('Authentication required'), { statusCode: 401 });
  const sb = publicClient();
  const { data, error } = await sb.auth.getUser(token);
  if (error || !data.user) throw Object.assign(new Error('Invalid or expired session'), { statusCode: 401 });
  const db = adminClient();
  const { data: profile, error: pErr } = await db.from('profiles').select('*').eq('id', data.user.id).single();
  if (pErr) throw Object.assign(new Error('Profile not found'), { statusCode: 403 });
  return { user: data.user, profile, db };
}

async function requireAdmin(req) {
  const result = await requireUser(req);
  if (result.profile.role !== 'admin') throw Object.assign(new Error('Admin access required'), { statusCode: 403 });
  return result;
}

function send(res, status, body) {
  res.status(status).json(body);
}

module.exports = { adminClient, publicClient, requireUser, requireAdmin, send };
