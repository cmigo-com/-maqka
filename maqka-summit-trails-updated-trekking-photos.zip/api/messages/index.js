const { requireUser, send } = require('../_lib/supabase');
const { sendEmail, templates } = require('../_lib/email');
const crypto = require('crypto');
const clean=(v,max=5000)=>String(v??'').trim().slice(0,max);
const conversationId=()=>`ST-MSG-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
module.exports=async(req,res)=>{
 try{
  const {user,profile,db}=await requireUser(req);
  if(req.method==='GET'){
   const {data,error}=await db.from('contact_messages').select('id,conversation_id,subject,message,status,created_at,updated_at,message_replies(id,sender_type,sender_name,body,email_status,created_at)').eq('user_id',user.id).order('created_at',{ascending:false});
   if(error)throw error; return send(res,200,{messages:data||[]});
  }
  if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
  const body=req.body||{};
  if(body.action==='create'){
   const message=clean(body.message),subject=clean(body.subject||'Customer message',180); if(!message)return send(res,400,{error:'Message is required.'});
   const conversation_id=conversationId();
   const {data:thread,error}=await db.from('contact_messages').insert({user_id:user.id,full_name:profile.full_name,email:user.email,phone:profile.phone_number||null,subject,message,conversation_id,status:'new'}).select().single(); if(error)throw error;
   const {error:rErr}=await db.from('message_replies').insert({contact_message_id:thread.id,sender_type:'customer',sender_name:profile.full_name||user.email,body:message,email_status:'not_sent'}); if(rErr)throw rErr;
   if(process.env.ADMIN_NOTIFICATION_EMAIL)await sendEmail({to:process.env.ADMIN_NOTIFICATION_EMAIL,subject:`Customer dashboard message — ${conversation_id}`,html:templates.customerMessageReply({name:'MAQKA SUMMIT TRAILS AND SAFARIS team',reply:`${profile.full_name||user.email} sent a message from their customer dashboard.\n\n${message}`,conversationId:conversation_id}),replyTo:user.email}).catch(()=>{});
   return send(res,201,{message:'Your message has been sent to MAQKA SUMMIT TRAILS AND SAFARIS.',conversation_id});
  }
  if(body.action==='reply'){
   const id=Number(body.message_id),message=clean(body.message); if(!id||!message)return send(res,400,{error:'Message and reply are required.'});
   const {data:thread,error:tErr}=await db.from('contact_messages').select('*').eq('id',id).eq('user_id',user.id).single(); if(tErr)throw tErr;
   const {error:rErr}=await db.from('message_replies').insert({contact_message_id:id,sender_type:'customer',sender_name:profile.full_name||user.email,body:message,email_status:'not_sent'}); if(rErr)throw rErr;
   await db.from('contact_messages').update({status:'new',updated_at:new Date().toISOString()}).eq('id',id);
   if(process.env.ADMIN_NOTIFICATION_EMAIL)await sendEmail({to:process.env.ADMIN_NOTIFICATION_EMAIL,subject:`Customer reply — ${thread.conversation_id}`,html:templates.customerMessageReply({name:'MAQKA SUMMIT TRAILS AND SAFARIS team',reply:`${profile.full_name||user.email} replied:\n\n${message}`,conversationId:thread.conversation_id}),replyTo:user.email}).catch(()=>{});
   return send(res,201,{message:'Your reply has been sent to MAQKA SUMMIT TRAILS AND SAFARIS.'});
  }
  return send(res,400,{error:'Unknown message action.'});
 }catch(e){return send(res,e.statusCode||500,{error:e.message});}
};
