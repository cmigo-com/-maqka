const { adminClient, send } = require('../_lib/supabase');
module.exports = async (req,res) => {
  try {
    if (req.method !== 'GET') return send(res,405,{error:'Method not allowed'});
    const db = adminClient();
    const type = String(req.query?.type || 'all');
    const result = {};
    if (type === 'all' || type === 'destinations') { const {data,error}=await db.from('destinations').select('*').eq('active',true).order('featured',{ascending:false}).order('name'); if(error)throw error; result.destinations=data||[]; }
    if (type === 'all' || type === 'safari') { const {data,error}=await db.from('safari_packages').select('*, safari_departures(*)').eq('active',true).order('featured',{ascending:false}).order('name'); if(error)throw error; result.safari_packages=data||[]; }
    if (type === 'all' || type === 'gallery') { const {data,error}=await db.from('gallery_images').select('*, adventures(title,slug)').eq('active',true).order('sort_order').order('created_at',{ascending:false}); if(error)throw error; result.gallery=data||[]; }
    if (type === 'all' || type === 'achievements') { const {data,error}=await db.from('achievements').select('*').eq('active',true).eq('verified',true).order('sort_order').order('year',{ascending:false}); if(error)throw error; result.achievements=data||[]; }
    if (type === 'all' || type === 'faqs') { const {data,error}=await db.from('faqs').select('*').eq('active',true).order('sort_order').order('id'); if(error)throw error; result.faqs=data||[]; }
    if (type === 'all' || type === 'settings') { const {data,error}=await db.from('site_settings').select('key,value').in('key',['site_logo_url']); if(error)throw error; result.settings=data||[]; }
    send(res,200,result);
  } catch(e) { send(res,500,{error:e.message}); }
};
