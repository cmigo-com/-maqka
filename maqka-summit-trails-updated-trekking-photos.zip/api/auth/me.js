const { requireUser, send } = require('../_lib/supabase');
module.exports=async(req,res)=>{try{if(req.method!=='GET')return send(res,405,{error:'Method not allowed'});const {user,profile}=await requireUser(req);send(res,200,{user:{id:user.id,email:user.email},profile});}catch(e){send(res,e.statusCode||500,{error:e.message});}};
