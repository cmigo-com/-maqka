const { requireUser, send } = require('../../_lib/supabase');
const { sendEmail, templates } = require('../../_lib/email');
module.exports = async (req,res) => {
  try {
    if(req.method!=='POST')return send(res,405,{error:'Method not allowed'});
    const {user,db}=await requireUser(req);
    const {data:profile,error:pErr}=await db.from('profiles').select('full_name,welcome_email_sent_at').eq('id',user.id).single(); if(pErr)throw pErr;
    if(profile.welcome_email_sent_at)return send(res,200,{sent:false,already_sent:true});
    const linkResult=await db.auth.admin.generateLink({type:'recovery',email:user.email,options:{redirectTo:`${process.env.SITE_URL||''}/login`}});
    const passwordSetupUrl=linkResult?.data?.properties?.action_link||'';
    const result=await sendEmail({to:user.email,subject:'Welcome to MAQKA SUMMIT TRAILS AND SAFARIS',html:templates.welcome({name:profile.full_name||user.email.split('@')[0],dashboardUrl:`${process.env.SITE_URL||''}/?page=dashboard`,passwordSetupUrl})});
    if(!result.sent)return send(res,503,{sent:false,error:'Email provider is not configured.'});
    await db.from('profiles').update({welcome_email_sent_at:new Date().toISOString()}).eq('id',user.id);
    return send(res,200,{sent:true});
  }catch(e){send(res,e.statusCode||500,{error:e.message});}
};
