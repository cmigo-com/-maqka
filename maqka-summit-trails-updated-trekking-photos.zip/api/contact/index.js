const crypto = require('crypto');
const { adminClient, requireUser, send } = require('../_lib/supabase');
const { sendEmail, templates, BRAND } = require('../_lib/email');

function clean(v,max=5000){return String(v??'').trim().slice(0,max)}
function hashToken(token){return crypto.createHash('sha256').update(token).digest('hex')}
function makeConversationId(){return `ST-MSG-${crypto.randomBytes(5).toString('hex').toUpperCase()}`}

module.exports = async (req,res) => {
  try {
    const db = adminClient();
    if (req.method !== 'POST') return send(res,405,{error:'Method not allowed'});
    const body=req.body||{};
    const action=body.action||'create';

    if(action==='create'){
      let sessionUser=null, sessionProfile=null;
      try { const session=await requireUser(req); sessionUser=session.user; sessionProfile=session.profile; } catch (_) {}
      const full_name=clean(body.full_name||body.name||sessionProfile?.full_name,120), email=clean(body.email||sessionUser?.email,180), phone=clean(body.phone||sessionProfile?.phone_number,40), message=clean(body.message,5000), subject=clean(body.subject||'MAQKA SUMMIT TRAILS AND SAFARIS enquiry',180), adventure_id=body.adventure_id?Number(body.adventure_id):null;
      if(!full_name||!email||!message) return send(res,400,{error:'Full name, email and message are required.'});
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res,400,{error:'Please provide a valid email address.'});
      const rawToken=crypto.randomBytes(24).toString('hex');
      const conversation_id=makeConversationId();
      const {data,error}=await db.from('contact_messages').insert({full_name,email,phone,subject,message,adventure_id,user_id:sessionUser?.id||null,conversation_id,reply_token_hash:hashToken(rawToken),reply_token_expires_at:new Date(Date.now()+90*24*60*60*1000).toISOString(),status:'new'}).select('*').single();
      if(error)throw error;
      await db.from('message_replies').insert({contact_message_id:data.id,sender_type:'customer',sender_name:full_name,body:message,email_status:'not_sent'});
      if(process.env.ADMIN_NOTIFICATION_EMAIL){
        await sendEmail({to:process.env.ADMIN_NOTIFICATION_EMAIL,subject:`New MAQKA SUMMIT TRAILS AND SAFARIS enquiry — ${conversation_id}`,html:templates.customerMessageReply({name:'MAQKA SUMMIT TRAILS AND SAFARIS team',reply:`New enquiry from ${full_name}. Email: ${email}. Phone: ${phone||'Not provided'}. Subject: ${subject}.\n\n${message}`,conversationId:conversation_id}),replyTo:email}).catch(()=>{});
      }
      const replyUrl=process.env.SITE_URL?`${process.env.SITE_URL.replace(/\/$/,'')}/contact?conversation=${encodeURIComponent(conversation_id)}&token=${encodeURIComponent(rawToken)}`:'';
      await sendEmail({to:email,subject:'Message Received — MAQKA SUMMIT TRAILS AND SAFARIS',html:templates.customerMessageReceived({name:full_name,conversationId:conversation_id,replyUrl})}).catch(()=>{});
      return send(res,201,{conversation_id,message:'Thank you for contacting MAQKA SUMMIT TRAILS AND SAFARIS. We have received your message and will get back to you shortly.'});
    }

    if(action==='customer_reply'){
      const conversation_id=clean(body.conversation_id,80), token=clean(body.token,120), message=clean(body.message,5000), email=clean(body.email,180);
      if(!conversation_id||!token||!message||!email) return send(res,400,{error:'Conversation, secure reply token, email and message are required.'});
      const {data:thread,error:tErr}=await db.from('contact_messages').select('*').eq('conversation_id',conversation_id).single(); if(tErr)throw tErr;
      if(thread.email!==email || thread.reply_token_hash!==hashToken(token) || (thread.reply_token_expires_at && new Date(thread.reply_token_expires_at)<new Date())) return send(res,403,{error:'This conversation link is invalid or expired.'});
      await db.from('message_replies').insert({contact_message_id:thread.id,sender_type:'customer',sender_name:thread.full_name,body:message,email_status:'not_sent'});
      await db.from('contact_messages').update({status:'new',updated_at:new Date().toISOString()}).eq('id',thread.id);
      if(process.env.ADMIN_NOTIFICATION_EMAIL) await sendEmail({to:process.env.ADMIN_NOTIFICATION_EMAIL,subject:`Customer reply — ${conversation_id}`,html:templates.customerMessageReply({name:'MAQKA SUMMIT TRAILS AND SAFARIS team',reply:`${thread.full_name} replied:\n\n${message}`,conversationId:conversation_id}),replyTo:thread.email}).catch(()=>{});
      return send(res,201,{message:'Your reply has been added to the conversation.'});
    }

    return send(res,400,{error:'Unknown contact action'});
  } catch(e) { send(res,e.statusCode||500,{error:e.message}); }
};
