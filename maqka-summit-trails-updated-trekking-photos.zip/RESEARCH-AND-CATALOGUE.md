# MAQKA SUMMIT TRAILS AND SAFARIS — Hiking Destination Research & Catalogue Plan

## Purpose

This document converts the client-supplied Tripadvisor research into an original MAQKA SUMMIT TRAILS AND SAFARIS destination catalogue. Tripadvisor material is treated as background research only. No traveler reviews, Tripadvisor marketing sentences, Tripadvisor photos or Tripadvisor prices are used as MAQKA SUMMIT TRAILS AND SAFARIS public content.

## Publication rule

- `active=true` means visible/bookable in the customer catalogue.
- `ready_for_catalogue=true` means there is enough destination-level information to structure a record, but it does **not** mean the adventure is ready to sell.
- Missing commercial values remain `Needs verification` or `Needs MAQKA SUMMIT TRAILS AND SAFARIS pricing`.
- MAQKA SUMMIT TRAILS AND SAFARIS Admin controls prices, departure dates, slots, featured status and active status.
- Existing confirmed bookings keep their stored adult/child unit prices and total; later price edits do not recalculate them.

## Current verification outcome

### Existing MAQKA SUMMIT TRAILS AND SAFARIS products retained as active
1. Mount Kenya — Point Lenana via Sirimon–Chogoria
2. Mount Longonot — Crater Rim Circuit

Their original MAQKA SUMMIT TRAILS AND SAFARIS adult prices and existing departure dates are retained. Child prices are not invented and therefore remain unset until MAQKA SUMMIT TRAILS AND SAFARIS provides them.

### Destination records structured for future verification/publication
- Karura Forest
- Ngong Hills
- Mount Satima
- Torok Waterfalls
- Ragia Falls
- Seven Ponds / Table Mountain
- Njine Kabia Falls
- Chagaik Arboretum
- Mt Kilimambogo
- Aberdare Hiking Adventure / Aberdare Forest
- Hell's Gate National Park
- Ndere Island National Park
- Maragoli Hills
- Menengai Crater
- Mount Lesatima & Dragon Teeth
- Mount Elgon
- Kakamega Forest
- Lake Elementaita

These records are seeded as inactive unless already an existing MAQKA SUMMIT TRAILS AND SAFARIS product. Admin must verify route, access, permits/ranger requirements, fees, meeting points, current opening arrangements, MAQKA SUMMIT TRAILS AND SAFARIS prices and departure dates before activating them.

### Research leads that should remain unpublished for now
- Oloolua Nature Trail
- Bamburi Nature Trail
- Boito Waterfalls
- Sigiria Nature Trail
- Oloolua Trails (duplicate/alternate naming)
- Mona Trails (operator/source, not a single destination)
- Oloololo Escarpment
- Nguruman Escarpment
- Ol Doinyo Eburru
- Nancy Beth Bird Sanctuary
- Karura Forest Trails (duplicate/alternate naming)

## Verified/current source themes

### Kenya Wildlife Service
Current KWS material confirms Mount Kenya as a high-altitude national park with Batian, Nelion and Point Lenana; KWS lists official access gates and current visitor/safety guidance. KWS also currently publishes destination information for Mount Longonot, Hell's Gate, Mount Elgon, Ndere Island, Kakamega Forest and Lake Elementaita.

### Kenya Forest Service
KFS confirms Karura Forest as a large urban gazetted forest with marked walking trails, waterfalls, Mau Mau caves, bird and butterfly life and forest-walking activities. KFS also lists forest stations relevant to Ngong Hills, Maragoli Hills, Eburru and the Aberdare forest system.

### National Tourism Service Portal
The official tourism portal identifies Mount Kenya, Aberdare, Hell's Gate, Karura, Ngong Hills, Kakamega and other nature destinations as part of Kenya's nature/adventure tourism offer. It is used for destination-level context, not for MAQKA SUMMIT TRAILS AND SAFARIS pricing.

## Items requiring explicit verification before activation

1. Current entry/park fees for the exact traveler category.
2. Current opening and closing arrangements.
3. Whether a guide/ranger is mandatory for the exact route.
4. Exact trailhead and meeting point.
5. Current route distance and elevation where secondary sources disagree.
6. Seasonal access, road conditions and weather restrictions.
7. Wildlife exposure and applicable safety protocols.
8. MAQKA SUMMIT TRAILS AND SAFARIS adult and child package prices.
9. MAQKA SUMMIT TRAILS AND SAFARIS inclusions/exclusions.
10. MAQKA SUMMIT TRAILS AND SAFARIS departure dates and maximum slots.
11. MAQKA SUMMIT TRAILS AND SAFARIS-owned/authorized photographs.

## Original public-content approach

Public descriptions are written specifically for MAQKA SUMMIT TRAILS AND SAFARIS. They describe the landscape, terrain and experience without presenting research-source reviews as customer feedback. No testimonials are generated from research.

## Source register

- Kenya Wildlife Service — Mount Kenya National Park
- Kenya Wildlife Service — Mount Longonot National Park
- Kenya Wildlife Service — Hell's Gate National Park
- Kenya Wildlife Service — Mount Elgon National Park
- Kenya Wildlife Service — Ndere Island National Park
- Kenya Wildlife Service — Kakamega Forest National Reserve
- Kenya Wildlife Service — Lake Elementaita Wildlife Sanctuary
- Kenya Forest Service — Karura Forest
- Kenya Forest Service — Our Forests / Conservancies
- National Tourism Service Portal — Eco-Tourism, Nature & Scenic Tourism
- National Tourism Service Portal — Central Kenya Circuit
- Current secondary/local sources were used only to identify research leads such as Ragia Falls, Torok Waterfalls, Njine Kabia Falls and Aberdare moorland routes. Their commercial details remain unverified in MAQKA SUMMIT TRAILS AND SAFARIS.

## Database implementation

`database/destination_catalogue.json` contains the structured research catalogue.

`database/seed_destination_catalogue.sql` seeds research-ready destinations as inactive so they can be reviewed in Admin before publication.

`database/schema.sql` adds:
- category, county, terrain and elevation fields
- original destination descriptions and highlights
- suitability and trip-format data
- what-to-bring and safety fields
- park/guide/opening-hours verification fields
- editable adult and child prices
- currency, discount and price status
- gallery image placeholders
- featured and active flags
- verification/source notes
- booking adult/child counts and price snapshots

## Booking pricing rule

For a new booking:

`Adult Price × Adults + Child Price × Children − Discount = Booking Total`

The adult/child unit prices and final total are stored on the booking record. Future admin price edits therefore do not alter an existing confirmed booking.

## 2026 Kenya trekking market comparison used in the website

The public Mount Kenya detail page includes a **market-reference comparison**, not a claim that the packages are identical. The comparison is based on published operator pages checked in October 2026 and is intended to help MAQKA SUMMIT TRAILS AND SAFARIS position its own editable prices.

| Operator | Published example | Kenyan | Resident | International | Notes |
|---|---|---:|---:|---:|---|
| Wild Springs Adventures | 5-day traverse | KES 48,000 | KES 65,000 | USD 950 | Published group-trek example with park/camping fees, Nairobi return transport, meals, KWS-certified guide, camping equipment and AMREF cover. |
| Ahambi Tours | 5-day trek | — | — | USD 900 pp (3+) | Published group price; route and group size affect final quote. |
| Mount Kenya Routes | 5-day Sirimon | — | — | USD 650 from | Published all-inclusive starting price; other durations/routes differ. |

Sources checked: Wild Springs Adventures, Ahambi Tours and Mount Kenya Routes. Prices are market references only and can change. MAQKA Admin remains responsible for MAQKA pricing and inclusions.
