# Summit Trails — Hikemaniak Price Research

Research date: 2026-09-29

These are **market-reference prices found on Hikemaniak pages**. They are NOT Summit Trails prices and are not automatically published or copied into the booking catalogue. Summit Trails administrators remain responsible for setting Summit Trails pricing, inclusions, deposits and departure dates.

| Adventure / comparable | Citizen KES | Resident KES | Non-resident | Source date / note |
|---|---:|---:|---:|---|
| Mt. Longonot | 2,750 | 2,750 | $75 | Hikemaniak page is an older 2023 listing; reference only |
| Ngong Hills Explore | 2,400 | 3,100 | $40 | Older 2023 listing; reference only |
| 4 Days Mt. Kenya Naromoru Sirimon | 52,500 | 54,500 | $950 | 2026 listing |
| 4 Days Mt. Kenya Lakes Tour — Chogoria | 48,500 | 48,500 | $850 | 2026 listing |
| Mt. Kenya Shipton Day Hike | 4,850 | 5,250 | $125 | 2026 listing |
| Mt. Kenya Point Peter | 62,500 | 64,500 | $1,150 | 2026 page/crawl; verify before using as a current benchmark |
| Mt. Kenya Batian Climb — North Face | 104,500 | 106,500 | $1,850 | 2026 listing |
| Mount Elgon Koitobos Peak | 58,500 | 58,500 | $850 | Current page; verify trip-date terms before using |
| Elephant Hill Bamboo Trek Aberdares | 3,850 | 4,250 | $125 | 2026 listing |
| Gatango Waterfall Chase — Aberdares Othaya | 3,850 | 4,250 | $65 | 2026 listing |
| Table Mountain Excursion — Elementaita | 3,850 | 4,250 | $65 | Listing contains older 2024 booking terms; verify before using |
| Mount Suswa Crater Excursion | 4,250 | 4,750 | $80 | 2026 listing |
| Ololokwe Hike N Camp | 16,500 | 18,500 | $250 | 2026 listing |

## Source pages

- https://hikemaniak.com/hike/mt-longonot/
- https://hikemaniak.com/hike/ngong-hills-explore-2/
- https://hikemaniak.com/hike/4-days-mt-kenya-naromoru-sirimon/
- https://hikemaniak.com/hike/4-days-mt-kenya-lakes-tour-chogoria/
- https://hikemaniak.com/hike/mt-kenya-shipton-hike/
- https://hikemaniak.com/hike/mt-kenya-point-peter-2/
- https://hikemaniak.com/hike/mount-kenya-batian-climb-north-face/
- https://hikemaniak.com/hike/mount-elgon-koitobos-peak/
- https://hikemaniak.com/hike/elephant-hill-bamboo-trek-aberdares/
- https://hikemaniak.com/hike/gatango-waterfall-chase-aberdares-othaya/
- https://hikemaniak.com/hike/table-mountain-excursion-elementaita/
- https://hikemaniak.com/hike/mount-suswa-crater-excursion/
- https://hikemaniak.com/hike/ololokwe-hike-n-camp/
